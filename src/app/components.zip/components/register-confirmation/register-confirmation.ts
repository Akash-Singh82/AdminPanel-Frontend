import { Component } from '@angular/core';

@Component({
  selector: 'app-register-confirmation',
  imports: [],
  templateUrl: './register-confirmation.html',
  styleUrl: './register-confirmation.scss'
})
export class RegisterConfirmation {

}
