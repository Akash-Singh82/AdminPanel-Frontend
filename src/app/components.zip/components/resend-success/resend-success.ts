import { Component } from '@angular/core';

@Component({
  selector: 'app-resend-success',
  imports: [],
  templateUrl: './resend-success.html',
  styleUrl: './resend-success.scss'
})
export class ResendSuccess {
  
}
