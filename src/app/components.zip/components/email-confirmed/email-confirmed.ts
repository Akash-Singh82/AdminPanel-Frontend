import { Component } from '@angular/core';

@Component({
  selector: 'app-email-confirmed',
  imports: [],
  templateUrl: './email-confirmed.html',
  styleUrl: './email-confirmed.scss'
})
export class EmailConfirmed {

}
